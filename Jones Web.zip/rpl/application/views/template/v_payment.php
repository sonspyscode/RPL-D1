<head>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>

    <link rel=”shortcut icon” href=”https://st3.depositphotos.com/3867453/14024/v/600/depositphotos_140245276-stock-illustration-letter-j-logo-icon-design.jpg”>
    <title>JONES | Login Page</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <?php $dataorder = $this->orderphoto->check_order($idorder)?>
</head>
<style>
body{
    width :100%;
    height: 100%;
    background-color: #073B4C;
    border-top: 20px;
    border-radius: 20px;
}
.content{
    text-align: center;
    color : white;
    padding : 20px;
} 
.isicontent{
    margin-top: 20px;
    background-color:white;
    padding : 20px;
    height:100%;
    width : 100%;
    border-top-left-radius: 30px;
    border-top-right-radius: 30px;
    color : black;
}
.header{
    display : block;
    margin : 20px;
}
.header h3{
    color :#073B4C;
    font-weight: 500;
    font-size: large;
    float : left;
}
.header h5{
    color : grey;
    font-weight: 500;
    font-size: large;
    margin : 10 -600 10 10;
    font-weight: 400;
}

.customer{
    display : block;
    margin: 10 20 0 20;
    text-align: left;
    
}
.customer h4{
    text-align: left;
    color : grey;
    font-size: medium;
    font-weight: 400;
}
.payment{
    display : block;
    list-style: none;
    position: absolute;
    left : 50%;    
    transform: translateX(-55%);
}
.payment li{
    width : 1000px;
    height : 50px;
    margin : 20px;
    background-color: #E9E5E5;
    color : #073B4C;
    font-weight: bold;
    padding : 10px;
    border-radius: 30px;
    text-align: left;
}
.payment li a{
    margin-left : 20px;
}
.btn{
    width : 150px;
}
</style>
<body>
    <div class="content">
        <h2>Payment</h2>
        <div class="isicontent">
            <div class="detail">
                <div class="header">
                    <h3 class="idorder">Id Order : <?php echo $dataorder['idorder']?></h3>
                    <h5 class="price">Total Price : Rp.<?php echo $dataorder['price']?></h5>
                </div>
                <div class="customer">
                    <h4><span>Name : </span><?php echo $dataorder['name']?></h4>
                    <h4><span>Address : </span><?php echo $dataorder['address']?></h4>
                    <h4><span>Package : </span><?php echo $dataorder['package']?></h4>
                    <h4><span>Quantity : </span><?php echo $dataorder['quantity']?> Person</h4>
                    <h4><span>Dateime : </span><?php echo $dataorder['date']?></h4>
                </div>
                <form action="<?= site_url('Payment/aksi_bayar')?>" method="post">
                    <div class="payment">
                    <input type="hidden" name="idorder" value="<?php echo $dataorder['idorder']?>">
                        <li>
                            <div class="radio">
                                <label><input type="radio" name="via" value="OVO"><a>OVO</a></label>
                            </div>
                        </li>
                        <li>
                            <div class="radio">
                                <label><input type="radio" name="via" value="GOPAY"><a>GO PAY</a></label>
                            </div>    
                        </li>
                        <li>
                            <div class="radio">
                                <label><input type="radio" name="via" value="LINKAJA"><a>LINK AJA</a></label>
                            </div>
                        </li>
                        <li>
                            <div class="radio">
                            <label><input type="radio" name="via" value="DANA"><a>DANA</a></label>
                        </div>
                        </li>
                        <div class="btn">
                            <a class="btn btn-danger" href="<?= base_url()?>Cekpayment">Back</a>
                            <button class="btn btn-primary" type="submit">Bayar</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</body>