<head>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>

    <link rel=”shortcut icon” href=”https://st3.depositphotos.com/3867453/14024/v/600/depositphotos_140245276-stock-illustration-letter-j-logo-icon-design.jpg”>
    <title>JONES | Login Page</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <?php $data = $this->account->get_profile($_SESSION['username']); ?>
</head>
<style>
body{
    width :100%;
    height: 100%;
    background-color: #073B4C;
    border-top: 20px;
    border-radius: 20px;
}
.content{
    text-align: center;
    color : white;
    padding : 20px;
} 
.isicontent{
    margin-top: 20px;
    background-color:white;
    padding : 20px;
    height : 80%;
    border-top-left-radius: 30px;
    border-top-right-radius: 30px;
    color : black;
    display : flex;
    align-items : center;
    justify-content: center;    
}

label{
    float: left;
    font-size: large;
    margin-bottom: 15px;
    text-align: left;
    margin-left: 20px;;
}
.detailuser{
    color :#073B4C;
    font-weight:500;
    display: block;
    font-size: 20px;
}
.detailUser #nama,#email,#nohp{
    color : grey;
    display: inline-block;
}
</style>
<body>
    <div class="content">
        <h2>Hallo, <?php echo $data['username']?></h2>
        <div class="isicontent">
            <div class="fotouser">
                <img class="rounded-circle z-depth-2" width="200px" height="200px" src="assets/pict/user.png" align="left" style="margin-left: 50px;">
            </div>
            <div class="detailuser">
                <div class="form-group row">
                    <label class="col-1 col-form-label">Name</label>
                    <label class="col-10 col-form-label" id="nama"><?php echo $data['nama']?></label>
                </div>
                <div class="form-group row">
                    <label class="col-1 col-form-label">Email</label>
                    <label class="col-10 col-form-label" id="email"><?php echo $data['email']?></label>
                </div>
                <div class="form-group row">
                    <label class="col-1 col-form-label">NoHp</label>
                    <label class="col-10 col-form-label" id="nohp"><?php echo $data['nohp']?></label>
                </div>
                <div class="form-group row">
                    <textarea class="form-control" id="exampleTextarea" placeholder="I am a student of informatics engineering at Telkom University" rows="4" style="width:800px;margin-top:20px;margin-left:20px" readonly></textarea>
                </div>
                <div class="form-group row">
                    <a class="btn btn-primary" style="position: absolute; left : 57%;transform: translateX(-50%);" href="<?= base_url()?>Changepassword">Change Password</a>
                </div>
            </div>
        </div>
    </div>
</body>