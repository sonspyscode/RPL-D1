<head>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>

    <link rel=”shortcut icon” href=”https://st3.depositphotos.com/3867453/14024/v/600/depositphotos_140245276-stock-illustration-letter-j-logo-icon-design.jpg”>
    <title>JONES | Check Order Page</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
</head>
<style>
body{
    width :100%;
    height: 100%;
    background-color: #073B4C;
    border-top: 20px;
    border-radius: 20px;
}
.content{
    text-align: center;
    color : white;
    padding : 20px;
} 
.isicontent{
    margin-top: 20px;
    background-color:white;
    padding : 20px;
    height: 100% auto; 
    width : 100%;
    border-top-left-radius: 30px;
    border-top-right-radius: 30px;
    color : black;
}
.isicontent h4{
    margin : 20px; 
    text-align: left;
    
}
.changepass{
    margin : 20px;
    width : 500px;
    /* height : 100% auto; */
    position: absolute;
    left : 50%;    
    transform: translateX(-50%);
}
.changepass label{
    float : left;
}
form{
    padding : 20px;
    width : 500px; 
    transform: translateX(80%);
}
form a,button{
    width : 150px;
}
</style>
<body>
    <div class="content">
        <h2>Change Password Page</h2>
        <div class="isicontent">
            <?php if(isset($error_message)) { ?>
                <div class="alert alert-danger" width="300px" role="alert">
                    <?= $error_message ?>
                </div>
            <?php } ?>
            <?php if(isset($success)) { ?>
                <div class="alert alert-success" width="300px" role="alert">
                   <?= $success ?>
                </div>
            <?php } ?>
            <form method="post" action="<?php echo base_url('changepassword/change'); ?>">
                <div class="form-group row">
                    <label for="formGroupExampleInput2">Password Lama</label>
                    <input type="password" class="form-control" id="formGroupExampleInput2" placeholder="Masukkan Password Lama Anda" name="passlama" required>
                </div>    
                <div class="form-group row">
                    <label for="formGroupExampleInput">Password Baru</label>
                    <input type="password" class="form-control" id="formGroupExampleInput" placeholder="Masukkan Password Baru Anda" name="passbaru" required>
                </div>
                <div class="form-group row">
                    <label for="formGroupExampleInput2">Verifikasi Password Baru</label>
                    <input type="password" class="form-control" id="formGroupExampleInput2" placeholder="Ulangi Masukkan Password Baru Anda" name="vpassbaru"required>
                </div>
                <div class="menu">
                    <a class="btn btn-danger" href="<?= base_url()?>Profile">Back</a>
                    <button class="btn btn-primary" type="submit" >Submit</a>
                </div>
            </form>
        </div>
    </div>
</body>