<head>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@5.15.3/css/fontawesome.min.css" integrity="undefined" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.5.0/font/bootstrap-icons.css">
    <link rel=”shortcut icon” href=”https://st3.depositphotos.com/3867453/14024/v/600/depositphotos_140245276-stock-illustration-letter-j-logo-icon-design.jpg”>
    <title>JONES | House of Photography</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <?php 
        $data = $this->account->get_profile($_SESSION['username']);
    ?>
<head>
<style>
nav{
    background-color: #073B4C;
    width : 100%;
    padding : 20px;
    height: 70px;
}
nav .nav_header{
    color : white;
    float : left;
    display : block;
}
nav .nav_header li {
    list-style: none;
    margin : auto;
}
nav .nav_header li a{
    text-align: center;
    font-weight: bold;
    display: block;
    font-size: small;
}
nav .menu{
    margin : auto;
}
nav .menu li{
    margin-left : 50px;
    display: inline-block;
    list-style: none;
    float: left;
}
nav .menu li a{
    color : white;
    text-transform: uppercase;
    font-weight: bold;
}
nav .account{
    text-align: right;
    margin : auto;
}
nav .account li{
    list-style : none;
    display: inline;
    color: white;
}
nav .account li a{
    color : white;
    display: inline-block;
    font-size: large;
    font-weight: lighter;
    margin-right: 20px;
}
</style>
<body>
    <nav>
       <div class="nav_header">
            <li><a style="font-size :large; ">JONES</a>
            <li><a style="font-weight:400">House of Photography</a></li>
        </div>
        <ul class="menu">
                <li><a href="<?= base_url()?>studio"><i class="bi bi-house-door"></i> Studio</a></li>
                <li><a href="<?= base_url()?>Order"><i class="bi bi-cart-plus"></i> Order</a></li>
                <li><a href="<?= base_url()?>Cekpayment"><i class="bi bi-wallet2"></i> Payment</a></li> 
                <li><a href="<?= base_url()?>Cekalbum"><i class="bi bi-card-image"></i> Album</a></li> 
                <li><a href="<?= base_url()?>Listorder"><i class="bi bi-clipboard" color="white"></i> History Order</a></li> 
        </ul>
        <ul class="account">
            <li><a>Hello, <?php echo $_SESSION['nama']?></a></li>
            <li><a href="<?= base_url()?>Profile"><i class="bi bi-person-circle"></i></a></li> 
            <li><a href="<?= base_url()?>Logout"><i class="bi bi-arrow-right-circle"></i></a></li> 
        </ul>
    </nav>
</body>