<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class changepassword extends CI_Controller 
{
	public function __construct()
	{
		 parent::__construct();
		 $this->load->library('session');
		 $this->load->helper('form');
		 $this->load->helper('url');
		 $this->load->helper('html');
		 $this->load->database();
		 $this->load->library('form_validation');
		 $this->load->model('account');
		 $this->load->model('orderphoto');
	}
 
   public function index()
      {
         $data = $this->account->get_profile($_SESSION['username']);
         if ($data['level'] == 'Admin'){
            $this->load->view('template/v_navbaradmin');
            $this->load->view('template/v_changepassword'); 
         } else if ($data['level'] == 'Photografer'){
            $this->load->view('template/v_navbarphotografer');
            $this->load->view('template/v_changepassword'); 
         } else{
            $this->load->view('template/v_navbarUser');
            $this->load->view('template/v_changepassword'); 
         }
      }
   public function change()
   {
      $getpass = $this->account->get_profile($_SESSION['username']);
      
      $input_passlama = $this->input->post('passlama', true);
      $input_passbaru1 = $this->input->post('passbaru', true);
      $input_passbaru2 = $this->input->post('vpassbaru', true);

      $data = [
			"password" => $this->input->post('passbaru', true),
         ];

      if($getpass['password'] == $input_passlama){
         if($input_passbaru1 != $input_passbaru2){
            if($getpass['level'] == 'Admin'){                         /// Apabila login sebagai admin
               $data['error_message'] = '<b>Gagal !</b> Password Baru Tidak Cocok';
               $this->load->view('template/v_navbaradmin', $getpass);
               $this->load->view('template/v_changepassword',$data);
             } else if ($getpass['level'] == "Member"){                /// Apabila Login sebagai member
               $data['error_message'] = '<b>Gagal !</b> Password Baru Tidak Cocok';
               $this->load->view('template/v_navbarUser', $getpass);
               $this->load->view('template/v_changepassword',$data);
             }
             else if ($getpass['level'] == "Photografer"){                /// Apabila Login sebagai photografer
               $data['error_message'] = '<b>Gagal !</b> Password Baru Tidak Cocok';
               $this->load->view('template/v_navbarphotografer', $getpass);
               $this->load->view('template/v_changepassword',$data);
             } 
         } else {
            if($this->account->change_password($_SESSION['username'],$data)){
               $data['success'] = 'Change Password <b></b>Success !</b>';
               if($getpass['level'] == 'Admin'){                         /// Apabila login sebagai admin
                  $this->load->view('template/v_navbaradmin', $getpass);
                  $this->load->view('template/v_changepassword',$data);
                } else if ($getpass['level'] == "Member"){                /// Apabila Login sebagai member
                  $this->load->view('template/v_navbarUser', $getpass);
                  $this->load->view('template/v_changepassword',$data);
                }
                else if ($getpass['level'] == "Photografer"){                /// Apabila Login sebagai photografer
                  $this->load->view('template/v_navbarphotografer', $getpass);
                  $this->load->view('template/v_changepassword',$data);
                } 
            }
            
         }         
      } else {
         if($getpass['level'] == 'Admin'){                         /// Apabila login sebagai admin
            $data['error_message'] = "<b>Gagal !</b> Password Lama salah";
            $this->load->view('template/v_navbaradmin', $getpass);
            $this->load->view('template/v_changepassword',$data);
          } else if ($getpass['level'] == "Member"){                /// Apabila Login sebagai member
            $data['error_message'] = "<b>Gagal !</b> Password Lama salah";
            $this->load->view('template/v_navbarUser', $getpass);
            $this->load->view('template/v_changepassword',$data);
          }
          else if ($getpass['level'] == "Photografer"){                /// Apabila Login sebagai photografer
            $data['error_message'] = "<b>Gagal !</b> Password Lama salah";
            $this->load->view('template/v_navbarphotografer', $getpass);
            $this->load->view('template/v_changepassword',$data);
          } 
      }
   }
}
?>