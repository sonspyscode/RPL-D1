<?php 
class Pembayaran extends CI_Model{

	public function insert_bayar($data)
	{
        $data = [
            "idpembayaran" => '',
            "idorder" => $this->input->post('idorder', true),
            "via" => $this->input->post('via', true),
            "status" => 'Success',
        ];
        return $this->db->insert('pembayaran',$data);
	}
	public function check_bayar($data){
		$query = $this->db->where('idorder',$data)->get('pembayaran');
		$count = $query->num_rows();
		if($count > 0){
			return true;
		}else{
			return false;
		}
	}
}