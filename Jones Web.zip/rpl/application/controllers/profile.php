<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Profile extends CI_Controller {
	public function __construct()
	{
		 parent::__construct();
		 $this->load->library('session');
		 $this->load->helper('form');
		 $this->load->helper('url');
		 $this->load->helper('html');
		 $this->load->database();
		 $this->load->library('form_validation');
		 $this->load->model('account');
	}
	public function index()
	{
        $data = $this->account->get_profile($_SESSION['username']);
		if($data['level'] == 'Admin'){                         /// Apabila login sebagai admin
			$this->load->view('template/v_navbaradmin', $data);
			$this->load->view('template/v_profile', $data);
		  } else if ($data['level'] == "Member"){                /// Apabila Login sebagai member
			$this->load->view('template/v_navbaruser', $data);
			$this->load->view('template/v_profile', $data);
		  }
		  else if ($data['level'] == "Photografer"){                /// Apabila Login sebagai photografer
			$this->load->view('template/v_navbarphotografer', $data);
			$this->load->view('template/v_profile', $data);
		  } 
	}
}
?>