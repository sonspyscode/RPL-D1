<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Register extends CI_Controller {
  public function __construct()
  {
       parent::__construct();
       $this->load->library('session');
       $this->load->helper('form');
       $this->load->helper('url');
       $this->load->helper('html');
       $this->load->database();
       $this->load->library('form_validation');
    
       $this->load->model('account');
  }
	public function index()
	{
		$this->load->view('template/v_registrasi');
	}

  public function aksi_register(){
		$data = [
			"username" => $this->input->post('username', true),
      "password" => $this->input->post('pass', true),
      "verifpass" => $this->input->post('verifpass', true),
      "nama" => $this->input->post('name', true),
      "email" => $this->input->post('email', true),
      "nohp" => $this->input->post('nohp', true),
      "level" => "Member"
    ];
    
    $already_exist = $this->account->check_username($data['username']);  
    $cek_pass = $this->account->check_password($data);

    $cekuser=  false;
    if (!$already_exist) { 
      $cekuser = true;
    }
    $cekpass = false;
    if ($cek_pass){
      $cekpass = true;
    }

    if(($cekuser ==true) && ($cekpass ==true)) {
      $this->account->insert_user($data);
      $data['success'] = 'Register New Account <b>Success !</b>';
      $this->load->view('template/v_registrasi',$data); 
  } else if(!$cekuser){
    $data['error_message'] = '<b>Gagal ! </b>Username already exist';
    $this->load->view('template/v_registrasi',$data); 
   } else if(!$cekpass){
    $data['error_message'] = '<b>Gagal ! </b>Password dont match';
    $this->load->view('template/v_registrasi',$data); 
   }
  }
}
?>