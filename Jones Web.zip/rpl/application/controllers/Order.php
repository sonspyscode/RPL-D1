<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Order extends CI_Controller {
	public function __construct()
	{
		 parent::__construct();
		 $this->load->library('session');
		 $this->load->helper('form');
		 $this->load->helper('url');
		 $this->load->helper('html');
		 $this->load->database();
		 $this->load->library('form_validation');
		 $this->load->model('account');
		 $this->load->model('orderphoto');
	}
	public function index()
	{
		$data = $this->account->get_profile($_SESSION['username']);
        $this->load->view('template/v_navbarUser', $data);
		$this->load->view('template/v_order', $data);
	}
	public function aksi_order()
	{
		if ($this->orderphoto->insert_order($_SESSION['username']))
		{
			$data['success'] = 'Order Sukses Brader';
			$this->load->view('template/v_navbarUser', $data);
			$this->load->view('template/v_order', $data);	
		}
		
	}
	public function delete($idorder)
	{
		$this->orderphoto->deleteorder($idorder);
		$data = $this->orderphoto->list_order_all();
	  	$data2 = $this->account->get_profile($_SESSION['username']);
	  	$this->load->view('template/v_navbaradmin', $data2);
      	$this->load->view('template/v_listorder', ['data'=>$data]);
   }
}

?>