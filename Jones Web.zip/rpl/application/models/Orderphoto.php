<?php 
class Orderphoto extends CI_Model{

	public function insert_order($username)
	{
		$data = [
            "idorder" => '',
			"status" => 'pending',
            "name" => $this->input->post('name', true),
            "nohp" => $this->input->post('nohp', true),
            "address" => $this->input->post('address', true),
			"quantity" => $this->input->post('quantity', true),
            "photografer" => $this->input->post('photografer', true),
            "package" => $this->input->post('package', true),
            "concept" => $this->input->post('concept', true),
            "date" => $this->input->post('date', true),
		];
        if ($data['package'] == "Ext photography Package"){
            $data['price'] = 50000;
        } else if ($data['package'] == "Int Photography Package"){
            $data['price'] = 75000;
        }
        return $this->db->insert('order',$data);
	}
	//end of nomor 1
	public function list_order_all(){
		$this->db->select('*');
		$this->db->from('order');
		$query = $this->db->get();
		return $query->result();
	}
    public function list_order_p($data){
		$this->db->select('*');
		$this->db->from('order');
        $this->db->where('photografer',$data);
		$query = $this->db->get();
		return $query->result();
	}
	public function list_order_user($data){
		$this->db->select('*');
		$this->db->from('order');
        $this->db->where('name',$data);
		$query = $this->db->get();
		return $query->result();
	}
	public function deleteorder($idorder)
	{
	    $this->db->where('idorder', $idorder);
        return $this->db->delete('order');
    }
    public function check_order($idorder)
	{
		if($this->db->where('idorder', $idorder)){
			return $this->db->get('order')->row_array();
		} else {
			return false;
		}
    }
    public function update_order($idorder,$update)
	{
		$data = [
			"status" => $update,
         ];
		$this->db->where('idorder', $idorder);
		return $this->db->update('order', $data);
    }
}