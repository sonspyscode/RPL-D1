<head>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>

    <link rel=”shortcut icon” href=”https://st3.depositphotos.com/3867453/14024/v/600/depositphotos_140245276-stock-illustration-letter-j-logo-icon-design.jpg”>
    <title>JONES | Login Page</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <?php 
        $data = $this->account->get_profile($_SESSION['username'])
    ?>
</head>
<style>
body{
    width :100%;
    height: 100%;
    background-color: #073B4C;
    border-top: 20px;
    border-radius: 20px;
}
.content{
    text-align: center;
    color : white;
    padding : 20px;
    
} 
.isicontent{
    margin-top: 20px;
    background-color:white;
    padding : 20px;
    height: 100% auto; 
    width : 100%;
    border-top-left-radius: 30px;
    border-top-right-radius: 30px;
    color : black;
}

label{
    float: left;
    font-size: large;
    margin-bottom: 15px;
    text-align: left;
    margin-left: 20px;;
}

form a,button {
    width : 150px;
}
hr{
  border: 2px solid #073B4C;
}
h3{
    text-align: left;
    color : #073B4C;
    margin : 20px;

}

</style>
<body>
    <div class="content">
        <h2>Order Page</h2>
        <div class="isicontent">
            <?php if(isset($success)) { ?>
                        <div class="alert alert-success" width="300px" role="alert">
                            <?= $success ?>
                        </div>
            <?php } ?>
            <form action="<?= base_url()?>order/aksi_order" method="POST">
            <h3>Personal Data Oder: </h3>
                <div class="form-group row">
                    <label for="example-name-input" class="col-2 col-form-label">Name</label>
                    <div class="col-8">
                        <input class="form-control" type="text" placeholder="Aditya Mahendra" id="example-password-input" name="name" value="<?php echo $data['nama']?>" readonly>
                    </div>
                </div>
                <div class="form-group row">
                    <label for="example-nohp-input" class="col-2 col-form-label">Phone Number</label>
                    <div class="col-8">
                        <input class="form-control" type="number" placeholder="Type Your Phone Number" id="example-number-input" name="nohp">
                    </div>
                </div>
                <div class="form-group row">
                    <label for="example-address-input" class="col-2 col-form-label">Address</label>
                    <div class="col-8">
                        <input class="form-control" type="text" placeholder="Type Your Address" id="example-number-input" name="address">
                    </div>
                </div>
                <hr>
                <h3>Detail Order : </h3>
                <div class="form-group row">
                    <label for="example-photografer-input" class="col-2 col-form-label">Photografer</label>
                    <div class="col-8">
                        <select class="form-control" name="photografer"id="exampleFormControlSelect1">
                        <option>Select your photografer</option>
                        <option value="Photografer A">Photografer A</option>
                        <option value="photografer B">Photografer B</option>
                        <option value="photografer C">Photografer C</option>
                        <option value="photografer D">Photografer D</option>
                        </select>
                    </div>
                </div>
                <div class="form-group row">
                    <label for="example-photografer-input" class="col-2 col-form-label">Quantity</label>
                    <div class="col-8">
                        <input class="form-control" type="text" placeholder="Type the number of people to be photographed" id="example-number-input" name="quantity">
                    </div>
                </div>
                <div class="form-group row">
                    <label for="example-photografer-input" class="col-2 col-form-label">Package</label>
                    <div class="col-8">
                        <select class="form-control" name="package" id="exampleFormControlSelect1">
                        <option>Select your package</option>
                        <option value="Ext photography Package">Ext photography Package</option>
                        <option value="Int Photography Package">Int Photography Package</option>
                        </select>
                    </div>
                </div>
                <div class="form-group row">
                    <label for="exampleTextarea"class="col-2 col-form-label">Concept Photo</label>
                    <div class="col-8">
                        <textarea class="form-control" id="exampleTextarea" placeholder="Type Your Concept Photo"  name="concept" rows="4"></textarea>
                    </div>
                </div>
                <div class="form-group row">
                    <label for="example-datetime-local-input" class="col-2 col-form-label">Date and time</label>
                    <div class="col-8">
                        <input class="form-control" type="datetime-local" placeholder="Please Select Your Date" name="date" id="example-datetime-local-input">
                    </div>
                </div>
                <div class="menu">
                    <a class="btn btn-danger" href="<?= base_url()?>">Back</a>
                    <button class="btn btn-info" type="submit" >Submit</a>
                </div>
            </form>
        </div>
    </div>
</body>