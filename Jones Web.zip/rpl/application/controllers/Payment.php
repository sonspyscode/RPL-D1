<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Payment extends CI_Controller {
	public function __construct()
	{
		 parent::__construct();
		 $this->load->library('session');
		 $this->load->helper('form');
		 $this->load->helper('url');
		 $this->load->helper('html');
		 $this->load->database();
		 $this->load->library('form_validation');
		 $this->load->model('account');
		 $this->load->model('orderphoto');
		 $this->load->model('pembayaran');
	}
	public function index()
	{
		$data = $this->account->get_profile($_SESSION['username']);
        $this->load->view('template/v_navbarUser',$data);
		$this->load->view('template/v_payment',$data);
	}
	public function aksi_bayar(){
		$data = [
			"idpembayaran" => '',
			"idorder" => $this->input->post('idorder', true),
			"via" => $this->input->post('via', true),
			"status" => 'Success',
		];
		if ($this->pembayaran->insert_bayar($data)){
			$data['success'] = "Your bill has been paid successfully";
			$this->load->view('template/v_navbarUser');
			$this->load->view('template/v_cekpayment',$data);
			}
	}
}
?>
