<head>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <link rel=”shortcut icon” href=”https://st3.depositphotos.com/3867453/14024/v/600/depositphotos_140245276-stock-illustration-letter-j-logo-icon-design.jpg”>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/7.33.1/sweetalert2.min.css">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.2/css/all.css" integrity="sha384-fnmOCqbTlWIlj8LyTjo7mOUStjsKC4pOpQbqyi7RrhN7udi9RwhKkMHpvLbHG9Sr" crossorigin="anonymous">
    <title>JONES | Register Page</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
</head>
<style>
.body{
    background-color: #073B4C;
    width : 100%;
    height: 100%;
    padding : 20px;
}
.body h2{
    color : white;
    margin-top: 20px;
    /* INI UNTUK MEMBUAT POSISI ELEMEN KE TENGAH */
    position: absolute;
    left : 50%;    
    transform: translateX(-50%);
    /* INI UNTUK MEMBUAT POSISI ELEMEN KE TENGAH */
}
.content h1{
    color : whitesmoke;
    font-size: 50px;
    text-align: center;
}
.content h3{
    font-family: 'Times New Roman', Times, serif;
    color : whitesmoke;
    text-align: center;
    font-size : 20px;
}
.form-login{ 
    margin-top : 10px;
    width : 500px;
    display: block;
    position: absolute;
    left : 50%;    
    transform: translateX(-50%);
}
.form-registrasi{
    border-radius: 30px;
    width : 500px;
    position: absolute;
    left : 50%;    
    transform: translateX(-50%);
}

.form-control{
    border-radius: 10px;
}
label{
    color : white;
}
.menu{
    margin-top: 20px;
    position: absolute;
    left : 50%;    
    transform: translateX(-50%);
}
.menu a,button{
    width : 120px;
}
.alert{
    width: 300px;
    left : 50%;
    transform: translateX(-50%);
}
</style>
<body>
    <div class="body">
        <div class="content">
            <h1>Registrasi</h1>
            <?php if(isset($error_message)) { ?>
                        <div class="alert alert-danger" width="300px" role="alert">
                            <?= $error_message ?>
                        </div>
            <?php } ?>
            <?php if(isset($success)) { ?>
                        <div class="alert alert-success" width="300px" role="alert">
                            <?= $success ?>
                        </div>
            <?php } ?>
        </div>
        <div class="form-registrasi">
            <form action="<?= base_url()?>Register/aksi_register" method="POST">
                <div class="form-label-group">
                    <label for="username">Username</label>
                    <input type="text" id="username" class="form-control" name="username" placeholder="type your username....." required>
                </div>
                <div class="form-label-group">
                    <label for="password">Name</label>
                    <input type="text" id="name" class="form-control" name="name"placeholder="type your name....." required>
                </div>
                <div class="form-label-group">
                    <label for="No HP">Phone Number</label>
                    <input type="number" id="nohp" class="form-control" name="nohp"placeholder="type your phone number....." required>
                </div>
                <div class="form-label-group">
                    <label for="password">Email</label>
                    <input type="text" id="email" class="form-control" name="email"placeholder="type your email....." required>
                </div>
                <div class="form-label-group">
                    <label for="username">Password</label>
                    <input type="password" id="password" class="form-control" name="pass"placeholder="type your password....." required>
                </div>
                <div class="form-label-group">
                    <label for="password">Confirm Password</label>
                    <input type="password" id="verifpass" class="form-control" name="verifpass"placeholder="re-type your password....." required>
                </div>
                <div class="menu">
                    <a class="btn btn-danger" href="<?= base_url()?>">Cancel</a>
                    <button class="btn btn-info" type="submit">Register</button>
                </div>
            </form>
        </div>
    </div>
    <script type="text/javascript">
          function sweetAlert() 
            {  
                Swal.fire('Any fool can use a computer') 
            }
    </script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/7.33.1/sweetalert2.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
</body>    