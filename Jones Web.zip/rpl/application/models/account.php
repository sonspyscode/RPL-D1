<?php 
class Account extends CI_Model{
    
    public function login($data) {
            $query = $this->db->where('username', $data['username'])->where('password', $data['password'])->get('user');
            if($query->num_rows() > 0){
                return true;
            }else{
                return false;
            }
		}

	public function insert_user($data)
	{
		$data = [
			"username" => $this->input->post('username', true),
            "password" => $this->input->post('pass', true),
            "nama" => $this->input->post('name', true),
            "email" => $this->input->post('email', true),
            "nohp" => $this->input->post('nohp', true),
            "level" => "Member"
		];
        return $this->db->insert('user',$data);
	}
	//end of nomor 1
    public function check_password($data) {
        if($data['password'] == $data['verifpass']){
            return true;
        } else {
            return false;
        }
    }
    public function check_username($username){
		$query = $this->db->where('username',$username)->get('user');
		$count = $query->num_rows();
		if($count > 0){
			return true;
		}else{
			return false;
		}
	}
    public function get_profile($username){
		if($this->db->where('username', $username)){
			return $this->db->get('user')->row_array();
		} else {
			return false;
		}
	}

	public function change_password($username,$data)
	{
		$data = [
			"password" => $this->input->post('passbaru', true),
         ];
		$this->db->where('username', $username);
		return $this->db->update('user', $data);
	}
}