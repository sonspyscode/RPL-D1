<head>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>

    <link rel=”shortcut icon” href=”https://st3.depositphotos.com/3867453/14024/v/600/depositphotos_140245276-stock-illustration-letter-j-logo-icon-design.jpg”>
    <title>JONES | List Order Page</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
</head>
<style>
body{
    width :100%;
    height: 100%;
    background-color: #073B4C;
    border-top: 20px;
    border-radius: 20px;
}
.content{
    text-align: center;
    color : white;
    padding : 20px;
} 
.isicontent{
    margin-top: 20px;
    background-color:white;
    padding : 20px;
    height:100%;
    width : 100%;
    border-top-left-radius: 30px;
    border-top-right-radius: 30px;
    color : black;
}
.panel-result{
    margin :20px;
}
th,td{
    text-align: center;
}
.aksi{
    display: inline;
}
.aksi a{
    display: inline-block;
    /* padding : 50px; */
    /* position: relative;? */
}

</style>
<body>
    <div class="content">
        <h2>LIST ORDER PAGE</h2>
        <div class="isicontent">
        <?php if(isset($error_message)) { ?>
                        <div class="alert alert-danger" width="300px" role="alert">
                            <?= $error_message ?>
                        </div>
            <?php } ?>
            <?php if(isset($success)) { ?>
                        <div class="alert alert-success" width="300px" role="alert">
                            <?= $success ?>
                        </div>
            <?php } ?>
            <div class="panel-result">
                <div class="panel-body">
                    <table class="table">
                        <thead class="thead-dark">
                            <tr>
                                <th>ID ORDER</th>
                                <th>NAMA</th>
                                <th>NO HP</th>
                                <th width="300px">ADDRESS</th>
                                <th width="50px">QUANTITY</th>
                                <th width="300px">PACKAGE</th>
                                <th>DATE</th>
                                <th>PRICE</th>
                                <th>STATUS</th>
                                <th colspan="2">ACTION</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $no = 1; 
                            foreach ($data as $d) {?>
                            <tr>
                                <td><?php echo $d->idorder ?></td>
                                <td><?php echo $d->name ?></td>
                                <td><?php echo $d->nohp ?></td>
                                <td><?php echo $d->address ?></td>
                                <td><?php echo $d->quantity?></td>
                                <td><?php echo $d->package?></td>
                                <td><?php echo $d->date ?></td>
                                <td><?php echo $d->price ?></td>
                                <td><?php if($d->status == "pending") { ?>
                                <div class="alert alert-info" width="300px" role="alert">
                                    <span>Pending</span>
                                </div>
                                <?php } else if($d->status == "success") { ?>
                                <div class="alert alert-info" width="300px" role="alert">
                                    <span>Success</span>
                                </div>
                                <?php } else if($d->status == "process") { ?>
                                <div class="alert alert-info" width="300px" role="alert">
                                    <span>Process</span>
                                </div>
                                <?php }?></td>
                                <td><?php if($d->status =="pending"){ ?>
                                    <a class="btn btn-danger" href="<?php echo base_url('ListOrder/Action/').$d->idorder; ?>" style="color:white;">Accept Order</a></td>
                                <?php } else if($d->status == "process"){?>
                                    <a class="btn btn-success"  href="<?php echo base_url('ListOrder/Action/').$d->idorder; ?>" style="color:white;">Finish</a>
                                    <td><a class="btn btn-danger"  href="#" ><i class="bi bi-upload"></i></a>
                                </div>
                                <?php } else if($d->status == "success"){?>
                                    <button type="button" class="btn btn-primary" disabled><i class="bi bi-check"></i></button>
                                <?php }?>
                            </tr>
                        </tbody>
                        <?php }?>
                    </table>
                </div>
            </div>
        </div>
    </div>
</body>