<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Login extends CI_Controller {
  public function __construct()
  {
       parent::__construct();
       $this->load->library('session');
       $this->load->helper('form');
       $this->load->helper('url');
       $this->load->helper('html');
       $this->load->database();
       $this->load->library('form_validation');
       //load the login model
       $this->load->model('account');
  }
	public function index()
	{
    $this->load->view('template/v_login');
	}
  public function aksi_login()
  {
      $data['username'] = $this->input->post('username');
      $data['password'] = $this->input->post('pass');
     if($this->account->login($data)) {
        $data = $this->account->get_profile($this->input->post('username'));

        $this->session->set_userdata('nama', $data['nama']); 
        $this->session->set_userdata('username', $data['username']);
        $this->session->set_userdata('password', $data['password']);
       
        if($data['level'] == 'Admin'){                         /// Apabila login sebagai admin
          $this->load->view('template/v_navbaradmin');
          $this->load->view('template/v_home');
        } else if ($data['level'] == "Member"){                /// Apabila Login sebagai member
          $this->load->view('template/v_navbaruser');
          $this->load->view('template/v_home');
        }
        else if ($data['level'] == "Photografer"){                /// Apabila Login sebagai photografer
          $this->load->view('template/v_navbarphotografer');
          $this->load->view('template/v_home');
        } 
     } else {
      $data['error_message'] = "invalid username or password";
      $this->load->view('template/v_login',$data); 
     }
  }
}
?>