<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Listorder extends CI_Controller {

	public function __construct()
	{
		 parent::__construct();
		 $this->load->library('session');
		 $this->load->helper('form');
		 $this->load->helper('url');
		 $this->load->helper('html');
		 $this->load->database();
		 $this->load->library('form_validation');
		 $this->load->model('account');
		 $this->load->model('orderphoto');
	}
  
 public function index(){
      $datauser = $_SESSION['nama'];
      $dataorder = $this->orderphoto->list_order_all();
      $dataorderp = $this->orderphoto->list_order_p($datauser);
      $dataorderuser = $this->orderphoto->list_order_user($datauser);
      $data = $this->account->get_profile($_SESSION['username']);
      if($data['level'] == 'Photografer'){
        $this->load->view('template/v_navbarphotografer', $data);
        $this->load->view('template/v_listorderp', ['data'=>$dataorderp]);
      }else if(($data['level'] == 'Member')){
        $this->load->view('template/v_navbarUser', $data);
        $this->load->view('template/v_listorder', ['data'=>$dataorderuser]);
      }else if(($data['level'] == 'Admin')){
      $this->load->view('template/v_navbaradmin', $data);
      $this->load->view('template/v_listorder', ['data'=>$dataorder]);
      }
  }
  public function Action($idorder)
  {

    $data = $this->account->get_profile($_SESSION['username']);
    $dataorder = $this->orderphoto->check_order($idorder);
    if ($dataorder['status'] == "pending"){
      $update = "process";
      $this->orderphoto->update_order($idorder,$update);
      $dataphotografer = $_SESSION['nama'];
      $dataorderp = $this->orderphoto->list_order_p($dataphotografer);
      $this->load->view('template/v_navbarphotografer',$data);
      $this->load->view('template/v_listorderp', ['data'=>$dataorderp]);
    } else if ($dataorder['status'] == "process"){
      $update = "success";
      $this->orderphoto->update_order($idorder,$update);
      $dataphotografer = $_SESSION['nama'];
      $dataorderp = $this->orderphoto->list_order_p($dataphotografer);
      $this->load->view('template/v_navbarphotografer',$data);
      $this->load->view('template/v_listorderp', ['data'=>$dataorderp]);
    }
  }  
}
?>